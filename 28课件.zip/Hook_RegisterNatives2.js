
var ishook_libart = false;

function hook_libart() {
    if (ishook_libart === true) {
        return;
    }
    var symbols = Module.enumerateSymbolsSync("libart.so");
    var RegisterNativesAddr = null;

    for (var i = 0; i < symbols.length; i++) {
        var symbol = symbols[i];
        if (symbol.name == "_ZN3art3JNI15RegisterNativesEP7_JNIEnvP7_jclassPK15JNINativeMethodi") {
            RegisterNativesAddr = symbol.address;
            console.log("RegisterNatives is at ", symbol.address, symbol.name);
        }
    }

    if (RegisterNativesAddr != null) {
        Interceptor.attach(RegisterNativesAddr, {
            onEnter: function (args) {
                console.log("[RegisterNatives] method_count:", args[3]);

                var methods = ptr(args[2]);
                var method_count = parseInt(args[3]);
                var env = Java.vm.tryGetEnv();
                var class_name = env.getClassName(args[1]);
                
                for (var i = 0; i < method_count; i++) {
                    var name = methods.add(i * Process.pointerSize * 3).readPointer().readCString();
                    var sig = methods.add(i * Process.pointerSize * 3 + Process.pointerSize).readPointer().readCString();
                    var fnPtr = methods.add(i * Process.pointerSize * 3 + Process.pointerSize * 2).readPointer();
                    var soInfo = Process.findModuleByAddress(fnPtr);
                    console.log("[RegisterNatives] javaClass:", class_name, "name:", name, "sig:", sig, "fnPtr:", fnPtr, "soName:", soInfo.name, "soBase:", soInfo.base, "funcOffset:", ptr(fnPtr).sub(soInfo.base));
                }

                
            },
            onLeave: function (retval) { }
        });
    }

    ishook_libart = true;
}

hook_libart();
