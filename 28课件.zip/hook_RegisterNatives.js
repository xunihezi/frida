
var ishook_libart = false;

function hook_libart() {
    if (ishook_libart === true) {
        return;
    }
    var symbols = Module.enumerateSymbolsSync("libart.so");
    var GetStringUTFCharsAddr = null;
    var GetMethodIDAddr = null;
    var RegisterNativesAddr = null;
    var CallObjectMethodAddr = null;
    var GetObjectClassAddr = null;
    var ReleaseStringUTFCharsAddr = null;
    for (var i = 0; i < symbols.length; i++) {
        var symbol = symbols[i];
        if (symbol.name == "_ZN3art3JNI17GetStringUTFCharsEP7_JNIEnvP8_jstringPh") {
            GetStringUTFCharsAddr = symbol.address;
            console.log("GetStringUTFChars is at ", symbol.address, symbol.name);
        } else if (symbol.name == "_ZN3art3JNI11GetMethodIDEP7_JNIEnvP7_jclassPKcS6_") {
            GetMethodIDAddr = symbol.address;
            console.log("GetMethodID is at ", symbol.address, symbol.name);
        } else if (symbol.name == "_ZN3art3JNI15RegisterNativesEP7_JNIEnvP7_jclassPK15JNINativeMethodi") {
            RegisterNativesAddr = symbol.address;
            console.log("RegisterNatives is at ", symbol.address, symbol.name);
        } else if (symbol.name.indexOf("_ZN3art3JNI16CallObjectMethodEP7_JNIEnvP8_jobjectP10_jmethodIDz") >= 0) {
            CallObjectMethodAddr = symbol.address;
            console.log("CallObjectMethod is at ", symbol.address, symbol.name);
        } else if (symbol.name.indexOf("_ZN3art3JNI14GetObjectClassEP7_JNIEnvP8_jobject") >= 0) {
            GetObjectClassAddr = symbol.address;
            console.log("GetObjectClass is at ", symbol.address, symbol.name);
        } else if (symbol.name.indexOf("_ZN3art3JNI21ReleaseStringUTFCharsEP7_JNIEnvP8_jstringPKc") >= 0) {
            ReleaseStringUTFCharsAddr = symbol.address;
            console.log("ReleaseStringUTFChars is at ", symbol.address, symbol.name);
        }
    }

    if (RegisterNativesAddr != null) {
        Interceptor.attach(RegisterNativesAddr, {
            onEnter: function (args) {
                console.log("[RegisterNatives] method_count:", args[3]);
                var env = args[0];
                var javaClass = args[1];
                var methods = ptr(args[2]);
                var method_count = parseInt(args[3]);

                var GetObjectClassFunc = new NativeFunction(GetObjectClassAddr, "pointer", ["pointer", "pointer"]);
                var GetMethodIDFunc = new NativeFunction(GetMethodIDAddr, "pointer", ["pointer", "pointer", "pointer", "pointer"]);
                var CallObjectMethodFunc = new NativeFunction(CallObjectMethodAddr, "pointer", ["pointer", "pointer", "pointer"]);
                var GetStringUTFCharsFunc = new NativeFunction(GetStringUTFCharsAddr, "pointer", ["pointer", "pointer", "pointer"]);
                var ReleaseStringUTFCharsFunc = new NativeFunction(ReleaseStringUTFCharsAddr, "void", ["pointer", "pointer", "pointer"]);

                var cls = GetObjectClassFunc(env, javaClass);
                var getNameID = GetMethodIDFunc(env, cls, Memory.allocUtf8String("getName"), Memory.allocUtf8String("()Ljava/lang/String;"));
                var name_jstring = CallObjectMethodFunc(env, javaClass, getNameID);
                var name_char = GetStringUTFCharsFunc(env, name_jstring, ptr(0));
                var class_name = ptr(name_char).readCString();
                
                for (var i = 0; i < method_count; i++) {
                    var name = methods.add(i * Process.pointerSize * 3).readPointer().readCString();
                    var sig = methods.add(i * Process.pointerSize * 3 + Process.pointerSize).readPointer().readCString();
                    var fnPtr = methods.add(i * Process.pointerSize * 3 + Process.pointerSize * 2).readPointer();
                    var soInfo = Process.findModuleByAddress(fnPtr);
                    console.log("[RegisterNatives] javaClass:", class_name, "name:", name, "sig:", sig, "fnPtr:", fnPtr, "soName:", soInfo.name, "soBase:", soInfo.base, "funcOffset:", ptr(fnPtr).sub(soInfo.base));
                }

                ReleaseStringUTFCharsFunc(env, name_jstring, name_char);
                
            },
            onLeave: function (retval) { }
        });
    }

    ishook_libart = true;
}

hook_libart();
