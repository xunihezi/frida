#include <stdio.h>

//char short int
//有符号无符号
//没有初始化 初始化为0 初始化其他数
//变量定义后其他地方有赋值

char g_char_null;
char g_char_0 = 0;
char g_char_100 = 100;

short g_short_null;
short g_short_0 = 0;
short g_short_100 = 100;

int g_int_null;
int g_int_0 = 0;
int g_int_100 = 100;

unsigned char g_unsignedchar_null;
unsigned char g_unsignedchar_0 = 0;
unsigned char g_unsignedchar_100 = 100;

unsigned short g_unsignedshort_null;
unsigned short g_unsignedshort_0 = 0;
unsigned short g_unsignedshort_100 = 100;

unsigned int g_unsignedint_null;
unsigned int g_unsignedint_0 = 0;
static unsigned int g_unsignedint_100 = 100;

float g_float = 100.6;
double g_double = 1000.5;

void func1(double dd){
	
}

void func2(double dd, float ff, int ii){
	
}

int main(){

	static char l_char_null;
	static char l_char_0 = 0;
	static char l_char_100 = 100;

	static short l_short_null;
	static short l_short_0 = 0;
	static short l_short_100 = 100;

	static int l_int_null;
	static int l_int_0 = 0;
	static int l_int_100 = 100;

	static unsigned char l_unsignedchar_null;
	static unsigned char l_unsignedchar_0 = 0;
	static unsigned char l_unsignedchar_100 = 100;

	static unsigned short l_unsignedshort_null;
	static unsigned short l_unsignedshort_0 = 0;
	static unsigned short l_unsignedshort_100 = 100;

	static unsigned int l_unsignedint_null;
	static unsigned int l_unsignedint_0 = 0;
	static unsigned int l_unsignedint_100 = 100;
	
	static float l_float = 100.6f;
	static double l_double = 500.6;
	
	l_int_null = 1000;
	l_char_0 = -100;
	g_unsignedchar_null = 254;
	g_char_0 = 128;
	g_unsignedshort_0 = 1000;
	
	printf("%d, %d, %d\n", g_char_null, g_char_0, g_char_100);
	printf("%d, %d, %d\n", g_short_null, g_short_0, g_short_100);
	printf("%d, %d, %d\n", g_int_null, g_int_0, g_int_100);
	
	printf("%d, %d, %d\n", g_unsignedchar_null, g_unsignedchar_0, g_unsignedchar_100);
	printf("%d, %d\n", g_unsignedshort_null, g_unsignedshort_100);
	printf("%d, %d, %d\n", g_unsignedint_null, g_unsignedint_0, g_unsignedint_100);
	
	printf("%d, %d, %d\n", l_char_null, l_char_0, l_char_100);
	printf("%d, %d, %d\n", l_short_null, l_short_0, l_short_100);
	printf("%d, %d, %d\n", l_int_null, l_int_0, l_int_100);
	
	printf("%d, %d, %d\n", l_unsignedchar_null, l_unsignedchar_0, l_unsignedchar_100);
	printf("%d, %d, %d\n", l_unsignedshort_null, l_unsignedshort_0, l_unsignedshort_100);
	printf("%d, %d, %d\n", l_unsignedint_null, l_unsignedint_0, l_unsignedint_100);
	
	printf("%lf\n", g_double);
	func1(g_double);
	func2(g_double, l_float, g_unsignedint_100);
	printf("%lf\n", l_double);
	printf("%f\n", g_float);
	printf("%f\n", l_float);
	
    int a,b,c,d;
    unsigned int e;

    a = 100;
    b = a;

    scanf("%d %d", &a, &b);

    printf("a=%d,b=%d\n", a, b);

    c = a + b;
    printf("a + b = %d\n", c);

    c = a - b;
    printf("a - b = %d\n", c);

    c = a * b;
    printf("a * b = %d\n", c);

    c = a / b;
    printf("a / b = %d\n", c);

    return 0;
}
