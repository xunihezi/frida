

function hook_art(){


    var dlsymAddr = Module.findExportByName(null,"dlsym");
    Interceptor.attach(dlsymAddr, {
        onEnter: function(args){
            this.funcName = ptr(args[1]).readCString();
        },
        onLeave: function(retval){
            if(Process.findModuleByAddress(retval)) console.log(Process.findModuleByAddress(retval).name + " " + this.funcName);
        }
    });

    // var symbols = Module.enumerateSymbolsSync("libart.so");
    // var FindNativeMethodInternalAddr = null;

    // for (var i = 0; i < symbols.length; i++) {
    //     var symbol = symbols[i];
    //     if(symbol.name == "_ZN3art9Libraries24FindNativeMethodInternalEPNS_6ThreadEPvPKcRKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEESE_") {
    //         FindNativeMethodInternalAddr = symbol.address;
    //         console.log("FindNativeMethodInternal is at ", symbol.address, symbol.name);
    //     } 
    // }

    // Interceptor.attach(FindNativeMethodInternalAddr, {
    //     onEnter: function(args){
    //         //console.log("FindNativeMethodInternalAddr onEnter args[0]: ", hexdump(args[0]));
    //         //console.log("FindNativeMethodInternalAddr onEnter args[1]: ", hexdump(args[1]));
    //         //console.log("FindNativeMethodInternalAddr onEnter args[2]: ", hexdump(args[2]));
    //         //console.log("FindNativeMethodInternalAddr onEnter args[3]: ", hexdump(args[3]));
    //         //console.log("FindNativeMethodInternalAddr onEnter args[4]: ", ptr(args[4]).add(Process.pointerSize * 2).readPointer().readCString());
    //         //console.log("FindNativeMethodInternalAddr onEnter args[5]: ", hexdump(args[5].add(Process.pointerSize * 2).readPointer()));

    //         //console.log("FindNativeMethodInternalAddr onEnter args[4]: ", hexdump(args[4].add(Process.pointerSize * 2).readPointer() ));
    //         this.funcName = ptr(args[4]).add(Process.pointerSize * 2).readPointer().readCString();
    //     },
    //     onLeave: function(retval){
    //         var soInfo = Process.findModuleByAddress(retval);
    //         console.log("FindNativeMethodInternalAddr onLeave retval: offset", retval.sub(parseInt(soInfo.base)), " ", this.funcName, " ",soInfo.path);
    //     }
    // });

}

function hook_dlopen(){
    var dlopen = Module.findExportByName(null, "dlopen");
    //console.log(dlopen);
    if(dlopen != null){
        Interceptor.attach(dlopen,{
            onEnter: function(args){
                var soName = args[0].readCString();
                //console.log(soName);
                if(soName.indexOf("libxiaojianbangA.so") != -1){
                    this.hook = true;
                }
            },
            onLeave: function(retval){
                if(this.hook) { hook_art() };
            }
        });
    }

    var android_dlopen_ext = Module.findExportByName(null, "android_dlopen_ext");
    //console.log(android_dlopen_ext);
    if(android_dlopen_ext != null){
        Interceptor.attach(android_dlopen_ext,{
            onEnter: function(args){
                var soName = args[0].readCString();
                //console.log(soName);
                if(soName.indexOf("libxiaojianbangA.so") != -1){
                    this.hook = true;
                }
            },
            onLeave: function(retval){
                if(this.hook) { hook_art() };
            }
        });
    }

}

function main(){
    hook_dlopen();
}

setImmediate(main);
